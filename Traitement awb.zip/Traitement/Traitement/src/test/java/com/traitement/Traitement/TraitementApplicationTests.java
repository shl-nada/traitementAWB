package com.traitement.Traitement;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TraitementApplicationTests {

	@Test
	void contextLoads() {
	}

}

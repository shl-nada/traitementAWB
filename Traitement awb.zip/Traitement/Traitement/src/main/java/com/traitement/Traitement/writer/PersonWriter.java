package com.traitement.Traitement.writer;

import com.traitement.Traitement.model.Person;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.batch.item.ItemWriter;
import org.springframework.batch.item.Chunk;

import java.io.File;
import java.io.IOException;
import java.util.List;

public class PersonWriter implements ItemWriter<Person> {

    private static final String OUTPUT_FILE_PATH = "src/main/resources/output/result.json";
    private final ObjectMapper objectMapper;

    public PersonWriter() {
        this.objectMapper = new ObjectMapper();
    }

    @Override
    public void write(Chunk<? extends Person> items) throws Exception {
        try {
            List<? extends Person> personList = items.getItems();
            objectMapper.writeValue(new File(OUTPUT_FILE_PATH), personList);
        } catch (IOException e) {
            throw new RuntimeException("Erreur lors de l'écriture du fichier JSON", e);
        }
    }
}

package com.traitement.Traitement.config;

import com.traitement.Traitement.model.Person;
import com.traitement.Traitement.processor.PersonProcessor;
import com.traitement.Traitement.reader.PersonReader;
import com.traitement.Traitement.writer.PersonWriter;
import org.springframework.batch.core.Step;
import org.springframework.batch.core.configuration.annotation.EnableBatchProcessing;
import org.springframework.batch.core.configuration.annotation.JobBuilderFactory;
import org.springframework.batch.core.configuration.annotation.StepBuilderFactory;
import org.springframework.batch.core.launch.support.RunIdIncrementer;
import org.springframework.batch.core.repository.JobRepository;
import org.springframework.batch.core.Job;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
@EnableBatchProcessing
public class BatchConfig {

    private final JobBuilderFactory jobBuilderFactory;
    private final StepBuilderFactory stepBuilderFactory;

    public BatchConfig(JobBuilderFactory jobBuilderFactory, StepBuilderFactory stepBuilderFactory) {
        this.jobBuilderFactory = jobBuilderFactory;
        this.stepBuilderFactory = stepBuilderFactory;
    }

    // Assurez-vous que StepBuilderFactory est bien injecté
    @Bean
    public StepBuilderFactory stepBuilderFactory() {
        return stepBuilderFactory;  // Pas besoin de redéfinir si déjà injecté
    }

    // Définir la méthode step1
    @Bean
    public Step step1() {
        return stepBuilderFactory.get("step1")
                .<Person, Person>chunk(10) // La taille du chunk, ajustez en fonction de vos besoins
                .reader(personReader()) // Le reader que vous définirez ailleurs
                .processor(personProcessor()) // Le processor que vous définirez ailleurs
                .writer(personWriter()) // Le writer que vous définirez ailleurs
                .build();
    }

    // Définir le job
    @Bean
    public Job job1(JobRepository jobRepository, Step step1) {
        return jobBuilderFactory.get("job1")
                .incrementer(new RunIdIncrementer())
                .start(step1)
                .build();
    }

    // Méthode pour la configuration du reader
    @Bean
    public PersonReader personReader() {
        return new PersonReader("src/main/resources/input/fichierV11.txt"); /
    }

    // Méthode pour la configuration du processor
    @Bean
    public PersonProcessor personProcessor() {
        return new PersonProcessor();
    }

    // Méthode pour la configuration du writer
    @Bean
    public PersonWriter personWriter() {
        return new PersonWriter();
    }
}

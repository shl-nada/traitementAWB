package com.traitement.Traitement.processor;

import com.traitement.Traitement.model.Person;
import org.springframework.batch.item.ItemProcessor;

public class PersonProcessor implements ItemProcessor<Person, Person> {

    @Override
    public Person process(Person item) throws Exception {
        return item;
    }
}

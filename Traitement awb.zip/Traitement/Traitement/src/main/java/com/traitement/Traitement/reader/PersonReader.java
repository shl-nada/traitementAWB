package com.traitement.Traitement.reader;

import com.traitement.Traitement.model.Person;
import org.springframework.batch.item.ItemReader;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

public class PersonReader implements ItemReader<Person> {

    private final String inputFile = "src/main/resources/input/fichierV11.txt";
    private BufferedReader reader;
    private String currentLine;

    public PersonReader() {
        try {
            reader = new BufferedReader(new FileReader(inputFile));
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    @Override
    public Person read() throws Exception {
        currentLine = reader.readLine();
        if (currentLine == null) {
            return null;
        }

        String[] values = currentLine.split(",");
        return new Person(values[0], values[1], Integer.parseInt(values[2]), values[3], values[4]);
    }

    public void close() throws IOException {
        if (reader != null) {
            reader.close();
        }
    }
}

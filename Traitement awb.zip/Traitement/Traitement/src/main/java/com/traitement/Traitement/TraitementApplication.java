package com.traitement.Traitement;


import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TraitementApplication {

	public static void main(String[] args) {
		SpringApplication.run(TraitementApplication.class, args);
	}
}


package com.traitement.Traitement.model;

public class Person {
    private String nom;
    private String prenoms;
    private int age;
    private String numcompte;
    private String ville;

    public Person(String nom, String prenoms, int age, String numcompte, String ville) {
        this.nom = nom;
        this.prenoms = prenoms;
        this.age = age;
        this.numcompte = numcompte;
        this.ville = ville;
    }
    public String getNom() {
        return nom;
    }
    public void setNom(String nom) {
        this.nom = nom;
    }
    public String getPrenoms() {
        return prenoms;
    }
    public void setPrenoms(String prenoms) {
        this.prenoms = prenoms;
    }
    public int getAge() {
        return age;
    }
    public void setAge(int age) {
        this.age = age;
    }
    public String getNumcompte() {
        return numcompte;
    }
    public void setNumcompte(String numcompte) {
        this.numcompte = numcompte;
    }
    public String getVille() {
        return ville;
    }
    public void setVille(String ville) {
        this.ville = ville;
    }
}
